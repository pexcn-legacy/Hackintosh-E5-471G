#!/bin/bash
java -jar DSDTParser.jar
